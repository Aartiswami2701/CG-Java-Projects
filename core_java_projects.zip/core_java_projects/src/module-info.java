/**
 * 
 */
/**
 * 
 */
module core_java_projects {
	requires java.naming;
}