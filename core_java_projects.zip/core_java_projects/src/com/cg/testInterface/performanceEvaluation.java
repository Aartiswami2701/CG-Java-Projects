package com.cg.testInterface;

public interface performanceEvaluation {
	void evaluatePerformance();
}
