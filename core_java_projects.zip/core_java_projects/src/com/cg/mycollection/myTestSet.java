package com.cg.mycollection;

import java.util.HashSet;
import java.util.LinkedHashSet;
import java.util.TreeSet;

public class myTestSet {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		/*HashSet s=new HashSet();
		s.add(1);
		s.add(2);
		s.add(3);
		s.add(4);
		s.add("aarti");
		s.add("capgi");
		s.add(null);
		System.out.println(" \n"+" HashSet would be:");
		
		System.out.println(s);*/
		
		/*LinkedHashSet s=new LinkedHashSet();
		s.add(1);
		s.add(2);
		s.add(3);
		s.add(4);
		s.add("aarti");
		s.add("capgi");
		s.add(null);
		System.out.println(" \n"+" HashSet would be:");
		
		System.out.println(s);*/
		
		TreeSet<Integer> s=new TreeSet<Integer>();
		s.add(8);
		s.add(2);
		s.add(3);
		s.add(4);
		//s.add("aarti");
		//s.add("capgi");
		System.out.println(" \n"+" HashSet would be:");
		
		System.out.println(s);
		
	}

}
