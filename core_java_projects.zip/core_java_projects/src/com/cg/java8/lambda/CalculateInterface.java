package com.cg.java8.lambda;
@FunctionalInterface
public interface CalculateInterface {
	int add(int a, int b);
}
