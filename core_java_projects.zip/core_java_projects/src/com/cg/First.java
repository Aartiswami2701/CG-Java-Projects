package com.cg;

import com.cg.basics.Employee1;

public class First {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		System.out.println("Hello Java");
		Employee1 e=new Employee1();
		System.out.println(e.getId());
		System.out.println(e.name);
		System.out.println(args[0]);
		System.out.println(args[1]);
	}

}
